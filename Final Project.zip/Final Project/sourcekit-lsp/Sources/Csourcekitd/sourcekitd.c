// This file is here to prevent the package manager from warning about a target with no sources.
