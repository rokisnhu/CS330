﻿#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

//files from previous module
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "type_ptr.hpp"
#include "shader.h"
#include "camera.h"
#include "glut.h"
using namespace std;
#include <iostream>
#include <windows.h> // for MS Windows #include <GL/glut.h> // GLUT, include glu.h and gl.h

struct GLMesh {
//vertex array object
GLuint vao; 
//vertex buffer object
GLuint vbo; 
GLuint nVertices; }; //indices of the mesh
// Main GLFW window
GLFWwindow* gWindow = nullptr;

// Triangle mesh data
GLMesh gMesh;
GLuint gTextureId;
glm::vec2 gUVScale(5.0f, 5.0f);
GLint gTexWrapMode = GL_REPEAT;

GLuint gCubeProgramId;
GLuint gLampProgramId;

// camera
Camera gCamera(glm::vec3(0.0f, 0.0f, 7.0f));
float gLastX = WINDOW_WIDTH / 2.0f;
float gLastY = WINDOW_HEIGHT / 2.0f;
bool gFirstMouse = true;
float gDeltaTime = 0.0f; // time between current frame and last frame
float gLastFrame = 0.0f;

//position and scale
glm::vec3 gCubePosition(0.0f, 0.0f, 0.0f);
glm::vec3 gCubeScale(2.0f);

//cube and light color
glm::vec3 gObjectColor(1.f, 0.2f, 0.0f);
glm::vec3 gLightColor(1.0f, 1.0f, 1.0f); //White light

// Light position and scale
glm::vec3 gLightPosition(-1.5f, 1.6f, 2.0f); //Key light
glm::vec3 gLightScale(0.3f);

bool gIsLampOrbiting = true; }
bool UInitialize(int, char*[], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh &mesh);
void UDestroyMesh(GLMesh &mesh);
bool UCreateTexture(const char* filename, GLuint &textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId);
void UDestroyShaderProgram(GLuint programId);


const GLchar * cubeVertexShaderSource = GLSL(440,
layout (location = 0) in vec3 position; 
layout (location = 1) in vec3 normal; 
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; 
out vec3 vertexFragmentPos; 
out vec2 vertexTextureCoordinate;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {
gl_Position = projection * view * model * vec4(position, 1.0f); 

vertexFragmentPos = vec3(model * vec4(position, 1.0f)); 
vertexNormal = mat3(transpose(inverse(model))) * normal; 
vertexTextureCoordinate = textureCoordinate; } )
const GLchar * cubeFragmentShaderSource = GLSL(440,

in vec3 vertexNormal; 
in vec3 vertexFragmentPos; 
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor;

//camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture;
uniform vec2 uvScale;

void main() {

//ambient lighting
float ambientStrength = 0.1f;
vec3 ambient = ambientStrength * lightColor; 


vec3 norm = normalize(vertexNormal); 
vec3 lightDirection = normalize(lightPos - vertexFragmentPos); 
float impact = max(dot(norm, lightDirection), 0.0);
vec3 diffuse = impact * lightColor; 


float specularIntensity = 0.8f; 
float highlightSize = 16.0f; 
vec3 viewDir = normalize(viewPosition - vertexFragmentPos); 
vec3 reflectDir = reflect(-lightDirection, norm);

float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
vec3 specular = specularIntensity * specularComponent * lightColor;
vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;
fragmentColor = vec4(phong, 1.0f); 

const GLchar * lampVertexShaderSource = GLSL(440,

layout (location = 0) in vec3 position; 
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {
gl_Position = projection * view * model * vec4(position, 1.0f); } ); 
const GLchar * lampFragmentShaderSource = GLSL(440,

out vec4 fragmentColor; 

void main() {
fragmentColor = vec4(1.0f); } ); 
void flipImageVertically(unsigned char *image, int width, int height, int channels) {
for (int j = 0; j < height / 2; ++j) {
int index1 = j * width * channels;
int index2 = (height - 1 - j) * width * channels;

for (int i = width * channels; i > 0; --i) {
unsigned char tmp = image[index1];
image[index1] = image[index2];
image[index2] = tmp;
++index1;
++index2; } } }
int main(int argc, char* argv[]) {
if (!UInitialize(argc, argv, &gWindow))
return EXIT_FAILURE;

// Create the mesh
UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

// Create the shader programs
if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gCubeProgramId))
return EXIT_FAILURE;

if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
return EXIT_FAILURE;

const char* texFilename = "../../resources/textures/brick.png";
if (!UCreateTexture(texFilename, gTextureId)) {
cout << "Failed to load texture " << texFilename << endl;
return EXIT_FAILURE; }
glUseProgram(gCubeProgramId);

glUniform1i(glGetUniformLocation(gCubeProgramId, "uTexture"), 0);
glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
while (!glfwWindowShouldClose(gWindow)) {
float currentFrame = glfwGetTime();
gDeltaTime = currentFrame - gLastFrame;
gLastFrame = currentFrame;

UProcessInput(gWindow);

URender();
glfwPollEvents(); }
UDestroyMesh(gMesh);
UDestroyTexture(gTextureId);

UDestroyShaderProgram(gCubeProgramId);
UDestroyShaderProgram(gLampProgramId);

exit(EXIT_SUCCESS); 
bool UInitialize(int argc, char* argv[], GLFWwindow** window) {

glfwInit();
glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);