var searchData=
[
  ['news_2edox_543',['news.dox',['../news_8dox.html',1,'']]]
];
